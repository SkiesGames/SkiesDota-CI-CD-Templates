# SSH Role

SSH key and agent management role.

## Features

- Generate and deliver SSH keys
- Setup SSH agent

## Usage

```yaml
- role: ssh
  tasks_from: generate_and_deliver
```
