# Docker Role

Docker installation and configuration role.

## Features

- Install Docker using official script
- Add user to docker group

## Usage

```yaml
- role: docker
```
