# Docker Compose Plugin Role

Docker Compose plugin management role.

## Features

- Install Docker Compose plugin
- Restart Docker Compose services

## Usage

```yaml
- role: docker_compose_plugin
  vars:
    app_dir: /opt/app
```
