# Deploy Role

Application deployment and synchronization role.

## Features

- File synchronization
- Environment configuration
- Docker Compose service management

## Usage

```yaml
- role: deploy
  vars:
    app_dir: /opt/app
```
